NANDA Town System Fitness Report
========================================
Run:       run-c4ed8998e29b
Profile:   flexgrid-market-day (fault: none)
Task:      quote 11 x flexgrid-nodes-closed at 1 cents, expecting 11 cents
Releases:  evaluator 0.5.0, flexgrid-core 0.2.0 c3c1bfc3d52c, nandatown 0.2.0, python 3.12.15
Started:   2026-11-08 11:00:58 UTC
Verdict:   PASSED
Rerun:     python examples/flexgrid/run_check.py --cases network_failure_rules

The journey: bring, connect, attempt, disrupt, inspect, improve.

Stages (each one a separate claim with its own failure boundary):
  accepted           Passed               the town committed the request before reporting success [ev-1062]
  claimed            Passed               a seller claimed the work under a lease [ev-1063]
  received           Passed               the seller acknowledged receipt through a valid fence [ev-1065]
  processed          Passed               the seller applied the task exactly once [ev-1065]
  response           Passed               the response was accepted and reached the buyer [ev-1064, ev-1066]
  correct            Passed               the buyer checked the total itself [ev-1067]
  portable_identity  Passed               the participant joined with a verified portable identity grant [ev-2, ev-4, ev-6, ev-8]
                     note: run grants verified against pinned controller keys for did:town:0300db2038c90242465984e1, did:town:0ec3f23d656593a0ec29ec72, did:town:19028d76d411d2afa66c7e1f, did:town:2d724496f2b8a281bb852ffc, did:town:343a69e5704944fed4e96407, did:town:37b6093cb5a207bb04dc0a65, did:town:4bec33e0a7b70d1a134d107c, did:town:565dc371aa5d9766ed2ab3b3, did:town:70c74fa91a247c04b0a6db4b, did:town:9ea3a060e4cae42930bcf95c, did:town:b4553f36978034d491a3ef34, did:town:c4ba47fd10a371470bacab4f, did:town:c9cd6385b8e7590c8ef76237, did:town:dea92c5017a0303fcf9480d6, did:town:e12c110d08eca5d346c29f62

Events recorded: 1068. Intents recorded: 2151.
This result applies only to the named agents, releases, scenario, failure, evaluator, and time window.
One run is one scoped observation, not a certificate.
Improve: fix what failed and rerun the same profile.
